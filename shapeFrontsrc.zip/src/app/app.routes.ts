import { Routes } from '@angular/router';
import { ShapeComponent } from './shape/shape.component';

export const routes: Routes = [
    { path: 'shape', component:ShapeComponent},


];
